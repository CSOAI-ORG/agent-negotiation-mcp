---
name: Bug Report
about: Report a bug to help us improve
title: "[BUG] "
labels: bug
assignees: ''
---

## Description

A clear description of the bug.

## Steps to Reproduce

1. 
2. 
3. 

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened.

## Environment

- Python version: 
- OS: 
- Package version: 

## Additional Context

Any other context about the problem.
